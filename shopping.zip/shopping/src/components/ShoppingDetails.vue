<template>
  <div class="details">
    <div class="detailsLeft">
      <img :src="destails.image" alt="">
    </div>
    <div class="datailsRight">
      <div class="box">
        <div class="title">{{destails.name}}</div>
        <div class="cost">￥ {{destails.cost}}</div>
        <button @click="addCart">加入购物车</button>
      </div>

    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      destails: Object
    }
  },
  mounted () {
    let id = this.$route.params.id
    this.getDetails(id)
  },
  methods: {
    getDetails (id) {
      let shoppingList = this.$store.state.productList
      shoppingList.forEach(item => {
        if (item.id.toString() === id) {
          this.destails = item
        }
      })
    },
    addCart () {
      this.$store.commit('addCart', this.destails)
    }
  }
}
</script>

<style scoped lang="less">
.details {
  position: relative;
  background-color: #ffffff;
  margin: 37px;
  border-radius: 5px;
  .detailsLeft {
    float: left;
    width: 50%;
    img {
      padding: 30px;
    }
  }
  .datailsRight {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    float: right;
    width: 50%;
    .box {
      position: relative;
      top: 50%;
      transform: translateY(-50%);
      text-align: center;
      .title {
        font-size: 40px;
        font-weight: 900;
      }
      .cost {
        margin-top: 5px;
        font-weight: 100;
        font-size: 17px;
      }
      button {
        margin-top: 14px;
        border: 0;
        width: 220px;
        height: 35px;
        color: #ffffff;
        border-radius: 3px;
        background-color: #f31717;
      }
    }
  }
  &:after{
      content: '';
      display: block;
      clear: both;
  }
}
</style>
