<template>
  <div class="grid">
    <div class="item">
      <img :src="propscart.image" alt="">
      <span>{{propscart.name}}</span>
    </div>
    <div class="sales">￥ {{propscart.sales}}</div>
    <div class="number">
      <span class="butAdd">+</span>
      {{propscart.count}}
      <span class="butRemove">-</span>
    </div>
    <div class="xiaoji">￥ </div>
    <div class="delete">删除</div>
  </div>
</template>

<script>
export default {
  props: {
    propscart: {
      type: Object
    }
  }
}
</script>

<style lang="less" scoped>
.grid {
  display: grid;
  grid-template-columns: 1fr 100px 100px 100px 100px;
  background-color: #ffffff;
  font-weight: 500;
  text-align: center;
  font-size: 18px;
  height: 50px;
  line-height: 50px;
  .item {
    text-indent: 50px;
    text-align: left;
    img {
      width: 40px;
      height: 40px;
      padding: 5px 0;
    }
    span {
      vertical-align: top;
    }
  }
  .number {
    span {
      display: inline-block;
      background-color: #d8d8d8;
      height: 24px;
      width: 24px;
      border-radius: 50%;
      vertical-align: top;
      margin: 13px 0;
      line-height: 24px;
      cursor: pointer;
    }
  }
}
</style>
