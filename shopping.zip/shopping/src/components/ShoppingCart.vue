<template>
  <div class="table">
    <div class="title">购物清单</div>
    <div v-for="(item, index) in cartListData" :key="index">
      <cart-list :propscart="item"></cart-list>
    </div>
  </div>
</template>

<script>
import cartList from './cartLIst'
export default {
  components: {
    cartList
  },
  computed: {
    cartListData () {
      return this.$store.state.cartList
    }
  }
}
</script>

<style scoped>

</style>
