<template>
  <div class="shoppinglist" v-if="productList[0]">
    <div class="filter">
      <div>
        品牌:
        <span @click="filterBrand(['Apple', 'Beats', 'Sonos', 'B&O', 'Bose'], 1)" :class="{selected: salesind === 1}">全部</span>
        <span @click="filterBrand(['Apple'], 2)" :class="{selected: salesind === 2}">Apple</span>
        <span @click="filterBrand(['Beats'], 3)" :class="{selected: salesind === 3}">Beats</span>
        <span @click="filterBrand(['Sonos'], 4)" :class="{selected: salesind === 4}">Sonos</span>
        <span @click="filterBrand(['B&O'], 5)" :class="{selected: salesind === 5}">B&O</span>
        <span @click="filterBrand(['Bose'], 6)" :class="{selected: salesind === 6}">Bose</span>
      </div>
      <div>
        颜色:
        <span @click="filterColor(['白色', '金色', '红色', '蓝色'], 1)" :class="{selected: colorind === 1}">全部</span>
        <span @click="filterColor(['白色'], 2)" :class="{selected: colorind === 2}">白色</span>
        <span @click="filterColor(['金色'], 3)" :class="{selected: colorind === 3}">金色</span>
        <span @click="filterColor(['红色'], 4)" :class="{selected: colorind === 4}">红色</span>
        <span @click="filterColor(['蓝色'], 5)" :class="{selected: colorind === 5}">蓝色</span>
      </div>
      <div class="sort">
        排序:
        <span @click="sort('默认')" :class="{selected: sortInt === 1}">默认</span>
        <span @click="sort('销量', order1)" :class="{selected: sortInt === 2}">销量
          <i v-if="order1 && sortInt === 2">↓</i><i v-if="!order1 && sortInt === 2">↑</i>
        </span>
        <span @click="sort('价格', order2)" :class="{selected: sortInt === 3}">价格
          <i v-if="order2 && sortInt === 3">↓</i><i v-if="!order2 && sortInt === 3">↑</i>
        </span>
      </div>
    </div>
    <div class="list">
      <div class="item" v-for="info in myfilter(productList)" :key="info.id">
        <property :info="info"></property>
      </div>
    </div>
  </div>
</template>

<script>
import property from './property'

export default {
  data () {
    return {
      order1: true,
      order2: true,
      color: ['白色', '金色', '红色', '蓝色'],
      brand: ['Apple', 'Beats', 'Sonos', 'B&O', 'Bose'],
      sortInt: 1,
      salesind: 1,
      colorind: 1
    }
  },
  components: {
    property
  },
  computed: {
    productList () {
      return this.$store.state.productList
    }
  },
  mounted () {
    this.$store.dispatch('getProductList')
  },
  methods: {
    sort (kind, order) {
      switch (kind) {
        case '默认':
          this.$store.commit('defaultSales')
          this.sortInt = 1
          break
        case '销量':
          this.$store.commit('sortSales', order)
          this.order1 = !order
          this.sortInt = 2
          break
        case '价格':
          this.$store.commit('priceSales', order)
          this.order2 = !order
          this.sortInt = 3
          break
        default:
          break
      }
    },
    myfilter (value) {
      let dom = []
      for (let i = 0; i < value.length; i++) {
        if (this.color.indexOf(value[i].color) !== -1 && this.brand.indexOf(value[i].brand) !== -1) {
          dom.push(value[i])
        }
      }
      return dom
    },
    filterColor (color, index) {
      this.colorind = index
      this.color.splice(0, this.color.length)
      this.color.push(...color)
    },
    filterBrand (brand, index) {
      this.salesind = index
      this.brand.splice(0, this.brand.length)
      this.brand.push(...brand)
    }
  }
}
</script>

<style scoped lang="less">
.shoppinglist {
  width: 98%;
  margin: 20px auto;
  .filter {
  background-color: #fafafa;
  padding: 15px;
  border-radius: 5px;
  box-shadow: 0 0 1px #9e9e9e;
  font-size: 18px;
  .sort {
    span {
      i {
        vertical-align: top;
      }
    }
  }
  div {
    margin: 15px 0;
    span {
      border: 1px solid #b8b8b8;
      border-radius: 3px;padding: 3px;
      margin: 0 3px;
      cursor: pointer;
    }
  }
  }
  .list {
    margin-top: 20px;
    .item {
      float: left;
      margin: 35px;
    }
    &:after{
      content: '';
      display: block;
      clear: both;
    }
  }
}
.selected {
  background-color: #444444;
  color: #ffffff;
}
</style>
