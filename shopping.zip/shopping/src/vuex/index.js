import Vue from 'vue'
import Vuex from 'vuex'
import data from './../data/data'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    productList: [],
    cartList: []
  },
  mutations: {
    setProductList (state, list) {
      state.productList = list
    },
    /**
     * 添加商品到购物车
     */
    addCart (state, thing) {
      const isAdded = state.cartList.find((value) => value.id === thing.id)
      if (isAdded) {
        isAdded.count++
      } else {
        state.cartList.push({
          id: thing.id,
          count: 1,
          brand: thing.brand,
          color: thing.color,
          cost: thing.cost,
          image: thing.image,
          name: thing.name,
          sales: thing.sales
        })
      }
    },
    /**
     * 按销量排序
     */
    sortSales (state, order) {
      if (order) {
        state.productList.sort((x, y) => {
          return y.sales - x.sales
        })
      } else {
        state.productList.sort((x, y) => {
          return x.sales - y.sales
        })
      }
    },
    /**
     * 按默认排序
     */
    defaultSales (state) {
      state.productList.sort((x, y) => {
        return x.id - y.id
      })
    },
    /**
     * 按价格排序
     */
    priceSales (state, order) {
      if (order) {
        state.productList.sort((x, y) => {
          return y.cost - x.cost
        })
      } else {
        state.productList.sort((x, y) => {
          return x.cost - y.cost
        })
      }
    }
  },
  actions: {
    getProductList (content) {
      setTimeout(() => {
        content.commit('setProductList', data)
      }, 500)
    }
  }
})
